export const analyticsAssets = {};
