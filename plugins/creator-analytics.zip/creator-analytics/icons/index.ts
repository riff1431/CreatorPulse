export const analyticsIcons = { main: '📊' };
