export * from './plugin.config';
